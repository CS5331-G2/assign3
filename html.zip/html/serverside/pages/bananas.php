<?php

echo("Bananas cost $2");

?>
