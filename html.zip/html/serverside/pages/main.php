<h1>Price Checker</h1>

<a href="?page=apples">Apples</a>
<a href="?page=oranges">Oranges</a>
<a href="?page=bananas">Bananas</a>
