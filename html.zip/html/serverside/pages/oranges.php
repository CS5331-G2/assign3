<?php

echo("Oranges cost $3");

?>
