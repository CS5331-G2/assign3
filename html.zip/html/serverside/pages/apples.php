<?php

echo("Apples cost $1");

?>
