<?php

// If you can read this, you've succeeded.

?>
